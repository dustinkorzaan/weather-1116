namespace FrontEnd.Data;

public class WeatherForecastClient
{
    private readonly HttpClient _httpClient;
    private readonly ILogger<WeatherForecastClient> _logger;

    public WeatherForecastClient(HttpClient httpClient, ILogger<WeatherForecastClient> logger)
    {
        _httpClient = httpClient;
        _logger = logger;
    }

    public async Task<WeatherForecast[]> GetForecastAsync(DateTime? startDate)
        => await _httpClient.GetFromJsonAsync<WeatherForecast[]>($"WeatherForecast?startDate={startDate}") ?? [];

    public async Task<WeatherSummaryResponse> GetWeatherSummaryAsync()
    {
        var response = await _httpClient.PostAsJsonAsync("llm/weather-summary", new { });
        response.EnsureSuccessStatusCode();

        var summary = await response.Content.ReadFromJsonAsync<WeatherSummaryResponse>();
        return summary ?? new WeatherSummaryResponse(
            "Weather summary",
            "No summary was returned by the model.",
            [],
            [],
            "<p>No summary was returned by the model.</p>");
    }

    public async Task<string> SendPromptAsync(string prompt)
    {
        var response = await _httpClient.PostAsJsonAsync("llm/prompt", new LlmPromptRequest(prompt));
        response.EnsureSuccessStatusCode();

        var llmResponse = await response.Content.ReadFromJsonAsync<LlmResponse>();
        return llmResponse?.Response ?? "No response was returned by the model.";
    }
}

public record LlmPromptRequest(string Prompt);
public record LlmResponse(string? Response);
public record WeatherSummaryResponse(
    string Headline,
    string OverallCondition,
    string[] ClothingTips,
    string[] OutdoorTips,
    string HtmlSummary);

using Microsoft.AspNetCore.OpenApi;
using OpenAI;
using OpenAI.Chat;
using OpenAI.Responses;
using Scalar.AspNetCore;
using System.ClientModel;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

#pragma warning disable OPENAI001

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi(options =>
{
    // current workaround for port forwarding in codespaces
    // https://github.com/dotnet/aspnetcore/issues/57332
    options.AddDocumentTransformer((document, context, ct) =>
    {
        document.Servers = [];
        return Task.CompletedTask;
    });
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.MapScalarApiReference();
}

app.UseHttpsRedirection();

var foundryEndpoint = builder.Configuration["Foundry:Endpoint"]
    ?? Environment.GetEnvironmentVariable("FOUNDRY_ENDPOINT");
var foundryModel = builder.Configuration["Foundry:Deployment"]
    ?? Environment.GetEnvironmentVariable("FOUNDRY_DEPLOYMENT");
var foundryApiKey = builder.Configuration["Foundry:ApiKey"]
    ?? Environment.GetEnvironmentVariable("FOUNDRY_API_KEY");

var summaries = new[]
{
    "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
};

app.MapPost("/llm/weather-summary", async (ILogger<Program> logger) =>
{
    var forecast = GenerateRandomForecast(summaries);
    var response = await GetStructuredWeatherSummaryAsync(forecast, foundryEndpoint, foundryModel, foundryApiKey, logger);
    return response is null
        ? Results.Problem("Foundry LLM request failed. Check server logs and configuration.", statusCode: StatusCodes.Status502BadGateway)
        : Results.Ok(new WeatherSummaryResponse(
            response.Headline,
            response.OverallCondition,
            response.ClothingTips,
            response.OutdoorTips,
            response.HtmlSummary));
})
.WithName("GetWeatherSummary");

app.MapPost("/llm/prompt", async (LlmPromptRequest request, ILogger<Program> logger) =>
{
    if (string.IsNullOrWhiteSpace(request.Prompt))
    {
        return Results.BadRequest("Prompt is required.");
    }

    var response = await GetFoundryResponseAsync(request.Prompt, foundryEndpoint, foundryModel, foundryApiKey, logger);
    return response is null
        ? Results.Problem("Foundry LLM request failed. Check server logs and configuration.", statusCode: StatusCodes.Status502BadGateway)
        : Results.Ok(new LlmResponse(response));
})
.WithName("PostPromptToLlm");

app.MapGet("/weatherforecast", () =>
{
    var forecast = Enumerable.Range(1, 5).Select(index =>
        new WeatherForecast
        (
            DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
            Random.Shared.Next(-20, 55),
            summaries[Random.Shared.Next(summaries.Length)]
        ))
        .ToArray();
    return forecast;
})
.WithName("GetWeatherForecast");

app.Run();

static WeatherForecast[] GenerateRandomForecast(string[] summaries)
{
    return Enumerable.Range(1, 5).Select(index =>
        new WeatherForecast
        (
            DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
            Random.Shared.Next(-20, 55),
            summaries[Random.Shared.Next(summaries.Length)]
        ))
        .ToArray();
}

static async Task<StructuredWeatherSummary?> GetStructuredWeatherSummaryAsync(
    WeatherForecast[] forecast,
    string? foundryEndpoint,
    string? foundryModel,
    string? foundryApiKey,
    ILogger logger)
{
    if (string.IsNullOrWhiteSpace(foundryEndpoint) || string.IsNullOrWhiteSpace(foundryModel) || string.IsNullOrWhiteSpace(foundryApiKey))
    {
        logger.LogError("Foundry configuration missing. Set Foundry:Endpoint/Deployment/ApiKey or FOUNDRY_ENDPOINT/FOUNDRY_DEPLOYMENT/FOUNDRY_API_KEY.");
        return null;
    }

    var schema = """
        {
          "type": "object",
          "properties": {
            "headline": { "type": "string" },
            "overallCondition": { "type": "string" },
            "clothingTips": {
              "type": "array",
              "items": { "type": "string" },
              "minItems": 2,
              "maxItems": 4
            },
            "outdoorTips": {
              "type": "array",
              "items": { "type": "string" },
              "minItems": 2,
              "maxItems": 4
            },
            "htmlSummary": { "type": "string" }
          },
          "required": ["headline", "overallCondition", "clothingTips", "outdoorTips", "htmlSummary"],
          "additionalProperties": false
        }
        """;

    try
    {
        var endpoint = foundryEndpoint.TrimEnd('/');

        ChatClient client = new(
            model: foundryModel,
            credential: new ApiKeyCredential(foundryApiKey),
            options: new OpenAIClientOptions
            {
                Endpoint = new Uri($"{endpoint}/openai/v1/")
            });

        var weatherJson = JsonSerializer.Serialize(new
        {
            generatedAtUtc = DateTime.UtcNow,
            unit = "celsius",
            forecast
        });

        List<ChatMessage> messages =
        [
            new SystemChatMessage("You are a weather assistant. Produce a concise, practical summary from provided weather JSON."),
            new UserChatMessage($"""
                Use the following weather JSON data to generate the response.

                Rules:
                - Keep the overall weather summary concise and practical.
                - htmlSummary must be valid HTML (not markdown), under 120 words, and include light emoji use.
                - Use only the provided weather data; do not invent locations or external conditions.

                Weather JSON:
                {weatherJson}
                """)
        ];

        ChatCompletionOptions options = new()
        {
            ResponseFormat = ChatResponseFormat.CreateJsonSchemaFormat(
                jsonSchemaFormatName: "weather_summary",
                jsonSchema: BinaryData.FromBytes(Encoding.UTF8.GetBytes(schema)),
                jsonSchemaIsStrict: true)
        };

        ChatCompletion completion = await client.CompleteChatAsync(messages, options);
        var content = completion.Content.FirstOrDefault()?.Text;
        if (string.IsNullOrWhiteSpace(content))
        {
            logger.LogError("Structured weather summary response was empty.");
            return null;
        }

        var rawJson = ExtractJsonObject(content);
        var structured = JsonSerializer.Deserialize<StructuredWeatherSummary>(
            rawJson,
            new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            });
        if (structured is null || string.IsNullOrWhiteSpace(structured.HtmlSummary))
        {
            logger.LogError("Structured weather summary response could not be parsed. Raw content: {Content}", content);
            return null;
        }

        return structured;
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "Foundry structured weather call failed.");
        return null;
    }
}

static string ExtractJsonObject(string content)
{
    var trimmed = content.Trim();
    var firstBrace = trimmed.IndexOf('{');
    var lastBrace = trimmed.LastIndexOf('}');

    if (firstBrace >= 0 && lastBrace > firstBrace)
    {
        return trimmed[firstBrace..(lastBrace + 1)];
    }

    return trimmed;
}

static async Task<string?> GetFoundryResponseAsync(
    string prompt,
    string? foundryEndpoint,
    string? foundryModel,
    string? foundryApiKey,
    ILogger logger)
{
    if (string.IsNullOrWhiteSpace(foundryEndpoint) || string.IsNullOrWhiteSpace(foundryModel) || string.IsNullOrWhiteSpace(foundryApiKey))
    {
        logger.LogError("Foundry configuration missing. Set Foundry:Endpoint/Deployment/ApiKey or FOUNDRY_ENDPOINT/FOUNDRY_DEPLOYMENT/FOUNDRY_API_KEY.");
        return null;
    }

    try
    {
        var endpoint = foundryEndpoint.TrimEnd('/');

        ResponsesClient client = new(
            new ApiKeyCredential(foundryApiKey),
            new ResponsesClientOptions
            {
                Endpoint = new Uri($"{endpoint}/openai/v1/")
            });

        var fullPrompt = $"You are a helpful assistant. Respond clearly and concisely.\n\n{prompt}";
        var response = await client.CreateResponseAsync(foundryModel, fullPrompt);
        return response.Value.GetOutputText();
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "Foundry call failed.");
        return null;
    }
}

internal record LlmPromptRequest(string Prompt);
internal record LlmResponse(string? Response);
internal record WeatherSummaryResponse(
    string Headline,
    string OverallCondition,
    string[] ClothingTips,
    string[] OutdoorTips,
    string HtmlSummary);

internal sealed class StructuredWeatherSummary
{
    [JsonPropertyName("headline")]
    public string Headline { get; init; } = string.Empty;

    [JsonPropertyName("overallCondition")]
    public string OverallCondition { get; init; } = string.Empty;

    [JsonPropertyName("clothingTips")]
    public string[] ClothingTips { get; init; } = [];

    [JsonPropertyName("outdoorTips")]
    public string[] OutdoorTips { get; init; } = [];

    [JsonPropertyName("htmlSummary")]
    public string HtmlSummary { get; init; } = string.Empty;
}

internal record WeatherForecast(DateOnly Date, int TemperatureC, string? Summary)
{
    public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);
}
